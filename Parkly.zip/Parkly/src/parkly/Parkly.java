package parkly;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Orientation;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;

public class Parkly extends Application
    implements EventHandler<ActionEvent> {
        
    
    @Override
    public void start(Stage primaryStage) throws Exception {
        parkingMethod();
        
    }
    
    public void parkingMethod(){
        Stage window = new Stage();
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane.setHgap(10);
        pane.setVgap(10);
        
        
        Label prompt = new Label("Where do you want to park?");
        GridPane.setConstraints(prompt, 0, 0);
        
        Button btGarage = new Button("Garage");
        GridPane.setConstraints(btGarage, 0, 1);
        
        Button btStreet = new Button("Street");
        GridPane.setConstraints(btStreet, 1, 1);
        
        pane.getChildren().addAll(prompt, btGarage, btStreet);
        
        Scene scene = new Scene(pane, 400, 200);
        window.setTitle("Parking Method");
        window.setScene(scene);
        window.show();
        
        btStreet.setOnAction(e -> meterOrNoMeter(window, scene, pane));
    }
    
    public void meterOrNoMeter(Stage window, Scene scene, GridPane pane){
        pane.getChildren().clear();
        Label prompt = new Label("Do you want to use a meter?");
        GridPane.setConstraints(prompt, 0, 0);
        
        Button btYes = new Button("Yes");
        GridPane.setConstraints(btYes, 0, 1);
        
        Button btNo = new Button("No");
        GridPane.setConstraints(btNo, 1, 1);
        
        pane.getChildren().addAll(prompt, btYes, btNo);
        
        window.setTitle("Meter or no Meter");
        window.setScene(scene);
        window.show();
        
        
        
    }
     
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void handle(ActionEvent event) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    
}
